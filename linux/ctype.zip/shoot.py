from action import keypress
import time
import pyautogui as bot

from ctype import KEY_W, KeybdInput, SendInput, Keyboard, keyboard_stream

time.sleep(5)
delay=60   
close_time=time.time()+delay

while True:



    SendInput(Keyboard(KEY_W))    

    if time.time()>close_time:
        break